<?php
if (!isset($_SESSION['ADMIN_USERID'])) {
    redirect(web_root . "admin/index.php");
}

global $mydb;
?>

<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">Active Scholars</h1>
    </div>
</div>

<!-- Summary Cards -->
<div class="row" style="margin-bottom: 15px;">
    <div class="col-lg-3 col-xs-6">
        <div class="small-box bg-green">
            <div class="inner">
                <?php
                $mydb->setQuery("SELECT COUNT(*) as total FROM tbl_scholarship_awards WHERE STATUS = 'Active'");
                $mydb->executeQuery();
                $active = $mydb->loadSingleResult();
                ?>
                <h3><?= $active->total ?? 0 ?></h3>
                <p>Active Scholars</p>
            </div>
            <div class="icon">
                <i class="fa fa-graduation-cap"></i>
            </div>
        </div>
    </div>
    
    <div class="col-lg-3 col-xs-6">
        <div class="small-box bg-yellow">
            <div class="inner">
                <?php
                $mydb->setQuery("SELECT COUNT(*) as total FROM tbl_scholarship_awards WHERE STATUS = 'Active' AND SCHOOL_YEAR = '2025-2026'");
                $mydb->executeQuery();
                $current = $mydb->loadSingleResult();
                ?>
                <h3><?= $current->total ?? 0 ?></h3>
                <p>Current School Year</p>
            </div>
            <div class="icon">
                <i class="fa fa-calendar"></i>
            </div>
        </div>
    </div>
    
    <div class="col-lg-3 col-xs-6">
        <div class="small-box bg-aqua">
            <div class="inner">
                <?php
                $mydb->setQuery("SELECT COUNT(*) as total FROM tbl_scholarship_awards WHERE STATUS = 'Active' AND SEMESTER = '2nd Semester'");
                $mydb->executeQuery();
                $second_sem = $mydb->loadSingleResult();
                ?>
                <h3><?= $second_sem->total ?? 0 ?></h3>
                <p>2nd Semester</p>
            </div>
            <div class="icon">
                <i class="fa fa-book"></i>
            </div>
        </div>
    </div>
    
    <div class="col-lg-3 col-xs-6">
        <div class="small-box bg-red">
            <div class="inner">
                <?php
                $mydb->setQuery("SELECT SUM(AMOUNT) as total FROM tbl_scholarship_awards WHERE STATUS = 'Active'");
                $mydb->executeQuery();
                $total_amount = $mydb->loadSingleResult();
                ?>
                <h3>₱ <?= number_format($total_amount->total ?? 0, 2) ?></h3>
                <p>Total Award Amount</p>
            </div>
            <div class="icon">
                <i class="fa fa-money"></i>
            </div>
        </div>
    </div>
</div>

<!-- Filter Section -->
<div class="row" style="margin-bottom: 15px;">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <i class="fa fa-filter"></i> Filter Scholars
            </div>
            <div class="panel-body">
                <form method="GET" action="index.php" class="form-inline">
                    <input type="hidden" name="view" value="list">
                    
                    <div class="form-group" style="margin-right: 10px;">
                        <label>School Year:</label>
                        <select name="school_year" class="form-control input-sm">
                            <option value="">All Years</option>
                            <option value="2024-2025" <?= isset($_GET['school_year']) && $_GET['school_year'] == '2024-2025' ? 'selected' : '' ?>>2024-2025</option>
                            <option value="2025-2026" <?= isset($_GET['school_year']) && $_GET['school_year'] == '2025-2026' ? 'selected' : '' ?>>2025-2026</option>
                            <option value="2026-2027" <?= isset($_GET['school_year']) && $_GET['school_year'] == '2026-2027' ? 'selected' : '' ?>>2026-2027</option>
                        </select>
                    </div>
                    
                    <div class="form-group" style="margin-right: 10px;">
                        <label>Municipality:</label>
                        <select name="municipality" class="form-control input-sm">
                            <option value="">All Municipalities</option>
                            <?php
                            $mydb->setQuery("SELECT DISTINCT MUNICIPALITY FROM tbl_applicants ORDER BY MUNICIPALITY");
                            $mydb->executeQuery();
                            $municipalities = $mydb->loadResultList();
                            foreach ($municipalities as $town):
                            ?>
                            <option value="<?= $town->MUNICIPALITY ?>" <?= isset($_GET['municipality']) && $_GET['municipality'] == $town->MUNICIPALITY ? 'selected' : '' ?>>
                                <?= $town->MUNICIPALITY ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group" style="margin-right: 10px;">
                        <label>Status:</label>
                        <select name="status" class="form-control input-sm">
                            <option value="Active" <?= !isset($_GET['status']) || $_GET['status'] == 'Active' ? 'selected' : '' ?>>Active</option>
                            <option value="Graduated" <?= isset($_GET['status']) && $_GET['status'] == 'Graduated' ? 'selected' : '' ?>>Graduated</option>
                            <option value="Terminated" <?= isset($_GET['status']) && $_GET['status'] == 'Terminated' ? 'selected' : '' ?>>Terminated</option>
                        </select>
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-sm">
                        <i class="fa fa-search"></i> Apply Filter
                    </button>
                    <a href="index.php?view=list" class="btn btn-default btn-sm">
                        <i class="fa fa-refresh"></i> Reset
                    </a>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Export Buttons -->
<div class="row">
    <div class="col-lg-12" style="margin-bottom: 10px;">
        <a href="#" onclick="window.print()" class="btn btn-default">
            <i class="fa fa-print"></i> Print List
        </a>
    </div>
</div>

<div class="table-responsive">
    <table id="dash-table" class="table table-striped table-bordered table-hover" style="font-size:13px">
        <thead>
            <tr>
                <th>Scholar ID</th>
                <th>Name</th>
                <th>Municipality</th>
                <th>School</th>
                <th>Course</th>
                <th>Year Level</th>
                <th>School Year</th>
                <th>Semester</th>
                <th>Award Amount</th>
                <th>Status</th>
                <th width="15%">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Build query with filters
            $where = array();
            $where[] = "sa.STATUS = '" . (isset($_GET['status']) ? $_GET['status'] : 'Active') . "'";
            
            if (isset($_GET['school_year']) && !empty($_GET['school_year'])) {
                $where[] = "sa.SCHOOL_YEAR = '" . $_GET['school_year'] . "'";
            }
            
            if (isset($_GET['municipality']) && !empty($_GET['municipality'])) {
                $where[] = "a.MUNICIPALITY = '" . $_GET['municipality'] . "'";
            }
            
            $where_clause = "WHERE " . implode(" AND ", $where);
            
            $sql = "
                SELECT 
                    sa.*,
                    a.LASTNAME, a.FIRSTNAME, a.MIDDLENAME, a.SUFFIX,
                    a.MUNICIPALITY, a.SCHOOL, a.COURSE, a.YEARLEVEL,
                    u.FULLNAME as AWARDED_BY_NAME
                FROM tbl_scholarship_awards sa
                INNER JOIN tbl_applicants a ON sa.APPLICANTID = a.APPLICANTID
                LEFT JOIN tblusers u ON sa.AWARDED_BY = u.USERID
                $where_clause
                ORDER BY a.LASTNAME ASC
            ";
            
            $mydb->setQuery($sql);
            $mydb->executeQuery();
            $scholars = $mydb->loadResultList();
            
            foreach ($scholars as $s):
                $status_color = match($s->STATUS) {
                    'Active' => 'label-success',
                    'Graduated' => 'label-primary',
                    'Terminated' => 'label-danger',
                    'Inactive' => 'label-warning',
                    default => 'label-default'
                };
            ?>
            <tr>
                <td><strong>SCH-<?= str_pad($s->AWARD_ID, 5, '0', STR_PAD_LEFT) ?></strong></td>
                <td><?= htmlspecialchars($s->LASTNAME . ', ' . $s->FIRSTNAME . ' ' . ($s->MIDDLENAME ?? '') . ' ' . ($s->SUFFIX ?? '')) ?></td>
                <td><?= htmlspecialchars($s->MUNICIPALITY ?? 'N/A') ?></td>
                <td><?= htmlspecialchars($s->SCHOOL ?? 'N/A') ?></td>
                <td><?= htmlspecialchars($s->COURSE ?? 'N/A') ?></td>
                <td><?= htmlspecialchars($s->YEARLEVEL ?? 'N/A') ?></td>
                <td><?= $s->SCHOOL_YEAR ?></td>
                <td><?= $s->SEMESTER ?></td>
                <td><strong>₱ <?= number_format($s->AMOUNT, 2) ?></strong></td>
                <td><span class="label <?= $status_color ?>"><?= $s->STATUS ?></span></td>
                <td class="text-center">
                    <a href="index.php?view=view&id=<?= $s->AWARD_ID ?>" class="btn btn-info btn-xs" title="View Details">
                        <i class="fa fa-eye"></i>
                    </a>
                    <?php if ($s->STATUS == 'Active'): ?>
                    <a href="index.php?view=renew&id=<?= $s->AWARD_ID ?>" class="btn btn-warning btn-xs" title="Process Renewal">
                        <i class="fa fa-refresh"></i>
                    </a>
                    <?php endif; ?>
                    <?php if ($_SESSION['ADMIN_ROLE'] == 'Super Admin'): ?>
                    <a href="controller.php?action=delete&id=<?= $s->AWARD_ID ?>" 
                       class="btn btn-danger btn-xs" 
                       onclick="return confirm('Delete this scholarship award? This action cannot be undone.')"
                       title="Delete">
                        <i class="fa fa-trash"></i>
                    </a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            
            <?php if (empty($scholars)): ?>
            <tr>
                <td colspan="11" class="text-center">
                    <div class="alert alert-info" style="margin: 20px;">
                        <i class="fa fa-info-circle"></i> No scholars found.
                    </div>
                </td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<script>
function exportToExcel() {
    window.location.href = 'export_scholars.php';
}

$(document).ready(function() {
    $('#dash-table').DataTable({
        "pageLength": 25,
        "order": [[1, "asc"]]
    });
});
</script>