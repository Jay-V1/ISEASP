<?php
require_once("../../include/initialize.php");
if (!isset($_SESSION['ADMIN_USERID'])) {
    redirect(web_root . "admin/index.php");
}

$view = (isset($_GET['view']) && $_GET['view'] != '') ? $_GET['view'] : '';
$title = "Scholars Management";
$subtitle = "";

switch ($view) {
    case 'view':
        $content = 'view.php';
        $subtitle = 'Scholar Details';
        break;
    case 'renew':
        $content = 'renew.php';
        $subtitle = 'Process Scholarship Renewal';
        break;
    case 'history':
        $content = 'history.php';
        $subtitle = 'Scholarship History';
        break;
    case 'graduate':
        $content = 'graduate.php';
        $subtitle = 'Graduates';
        break;
    case 'payroll':
        $content = 'payroll.php';
        $subtitle = 'Payroll Management';
        break;
    case 'payroll_details':
        $content = 'payroll_details.php';
        $subtitle = 'Payroll Details';
        break;
    case 'disbursement':
        $content = 'disbursement.php';
        $subtitle = 'Disbursement Records';
        break;
    case 'payroll_reports':
        $content = 'payroll_reports.php';
        $subtitle = 'Payroll Reports';
        break;
    case 'print_payroll':
        $content = 'print_payroll.php';
        $subtitle = 'Print Payroll';
        break;
    default:
        $content = 'main.php';
        $subtitle = 'Active Scholars';
}

require_once("../theme/templates.php");
?>